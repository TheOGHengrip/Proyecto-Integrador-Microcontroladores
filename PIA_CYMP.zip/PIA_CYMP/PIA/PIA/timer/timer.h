/*
 * timer.h
 *
 * Created: 23/11/2022 02:03:51 a. m.
 *  Author: angel
 */ 


#ifndef TIMER_H_
#define TIMER_H_

void init_timer(void);



#endif /* TIMER_H_ */