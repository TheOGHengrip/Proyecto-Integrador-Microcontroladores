/*
 * adc.h
 *
 * Created: 23/11/2022 08:35:19 p. m.
 *  Author: angel
 */ 


#ifndef ADC_H_
#define ADC_H_


void init_adc(void);
void ADC_on(void);



#endif /* ADC_H_ */